import { useState } from 'react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Radius } from 'lucide-react';

interface LoginScreenProps {
  onContinue: (email: string) => void;
  onSignupClick: () => void;
}

export function LoginScreen({ onContinue, onSignupClick }: LoginScreenProps) {
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      onContinue(email);
    }
  };

  return (
    <div className="h-full flex flex-col items-center justify-center px-8 bg-gradient-to-b from-white to-purple-50/30">
      <div className="w-full max-w-sm space-y-8">
        {/* Logo */}
        <div className="flex flex-col items-center space-y-4">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-lg">
            <Radius className="w-10 h-10 text-white" strokeWidth={2} />
          </div>
          <div className="text-center">
            <h1 className="text-3xl font-semibold text-gray-900 mb-2">Radius</h1>
            <p className="text-lg text-gray-600">Find your vibe nearby</p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-12 rounded-xl border-gray-200 focus:border-purple-500 focus:ring-purple-500"
              required
            />
          </div>

          <Button
            type="submit"
            className="w-full h-12 rounded-xl bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium shadow-lg shadow-purple-500/30 transition-all"
          >
            Continue
          </Button>
        </form>

        {/* Sign up link */}
        <div className="text-center">
          <button
            onClick={onSignupClick}
            className="text-sm text-gray-600 hover:text-purple-600 transition-colors"
          >
            Don't have an account? <span className="font-medium">Sign up</span>
          </button>
        </div>
      </div>
    </div>
  );
}
