import { useState } from 'react';
import { ArrowLeft, Send } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';

interface ChatsScreenProps {
  onBack: () => void;
}

const conversations = [
  {
    id: '1',
    name: 'Emma Wilson',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100',
    lastMessage: 'See you at the yoga session!',
    time: '2m ago',
    unread: 2,
    online: true,
  },
  {
    id: '2',
    name: 'Alex Chen',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100',
    lastMessage: 'That café was amazing, thanks!',
    time: '1h ago',
    unread: 0,
    online: true,
  },
  {
    id: '3',
    name: 'Sarah Martinez',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100',
    lastMessage: 'Let\'s meet up tomorrow',
    time: '3h ago',
    unread: 1,
    online: false,
  },
  {
    id: '4',
    name: 'Mike Johnson',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100',
    lastMessage: 'Great workout today! 💪',
    time: '5h ago',
    unread: 0,
    online: false,
  },
  {
    id: '5',
    name: 'Jordan Lee',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100',
    lastMessage: 'Found a new spot for studying',
    time: '1d ago',
    unread: 0,
    online: false,
  },
];

const chatMessages = {
  '1': [
    { sender: 'Emma Wilson', message: 'Hey! Are you joining the yoga session tomorrow?', time: '10:30 AM', isSelf: false },
    { sender: 'You', message: 'Yes! What time?', time: '10:32 AM', isSelf: true },
    { sender: 'Emma Wilson', message: 'See you at the yoga session!', time: '10:35 AM', isSelf: false },
  ],
  '2': [
    { sender: 'You', message: 'Check out this café I found!', time: '2:15 PM', isSelf: true },
    { sender: 'Alex Chen', message: 'That café was amazing, thanks!', time: '3:20 PM', isSelf: false },
  ],
};

export function ChatsScreen({ onBack }: ChatsScreenProps) {
  const [selectedChat, setSelectedChat] = useState<string | null>(null);
  const [message, setMessage] = useState('');

  if (selectedChat) {
    const conversation = conversations.find(c => c.id === selectedChat);
    const messages = chatMessages[selectedChat as keyof typeof chatMessages] || [];

    return (
      <div className="h-full flex flex-col bg-white">
        {/* Chat Header */}
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-4 shadow-lg">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setSelectedChat(null)} 
              className="hover:bg-white/20 rounded-full p-2 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <Avatar className="w-10 h-10 border-2 border-white">
              <AvatarImage src={conversation?.avatar} alt={conversation?.name} />
              <AvatarFallback className="bg-white/20 text-white text-sm">
                {conversation?.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h2 className="font-semibold">{conversation?.name}</h2>
              <p className="text-sm text-white/90">{conversation?.online ? 'Online' : 'Offline'}</p>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-3 bg-gray-50">
          {messages.map((msg, idx) => (
            <div key={idx} className={`flex ${msg.isSelf ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[75%] ${msg.isSelf ? 'items-end' : 'items-start'} flex flex-col gap-1`}>
                <div className={`rounded-2xl px-4 py-2 ${
                  msg.isSelf 
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-br-sm' 
                    : 'bg-white text-gray-800 rounded-bl-sm shadow-sm'
                }`}>
                  <p>{msg.message}</p>
                </div>
                <span className="text-xs text-gray-500 px-2">{msg.time}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Message Input */}
        <div className="border-t border-gray-200 bg-white px-6 py-4">
          <div className="flex gap-2">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type a message..."
              className="flex-1 h-11 rounded-full border-gray-300 focus:border-purple-500 focus:ring-purple-500"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && message.trim()) {
                  setMessage('');
                }
              }}
            />
            <Button
              onClick={() => message.trim() && setMessage('')}
              className="h-11 w-11 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 p-0 shadow-lg shadow-purple-500/30"
            >
              <Send className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-purple-50/50 to-blue-50/50">
      {/* Header */}
      <div className="px-6 pt-12 pb-6">
        <div className="flex items-center gap-3 mb-2">
          <button onClick={onBack} className="hover:bg-white/60 rounded-full p-2 transition-colors">
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
          <h1 className="text-3xl font-semibold text-gray-900">Messages</h1>
        </div>
        <p className="text-lg text-gray-600 ml-12">Your conversations</p>
      </div>

      {/* Conversations List */}
      <div className="flex-1 overflow-y-auto px-6 pb-6 space-y-3">
        {conversations.map((conv) => (
          <Card
            key={conv.id}
            onClick={() => setSelectedChat(conv.id)}
            className="bg-white border-0 shadow-md hover:shadow-lg transition-all cursor-pointer rounded-2xl"
          >
            <div className="flex items-center gap-4 p-4">
              <div className="relative">
                <Avatar className="w-14 h-14 border-2 border-purple-200">
                  <AvatarImage src={conv.avatar} alt={conv.name} />
                  <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                    {conv.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                {conv.online && (
                  <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <h3 className="font-semibold text-gray-900">{conv.name}</h3>
                  <span className="text-xs text-gray-500">{conv.time}</span>
                </div>
                <p className="text-sm text-gray-600 truncate">{conv.lastMessage}</p>
              </div>

              {conv.unread > 0 && (
                <div className="flex-shrink-0 w-6 h-6 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-full flex items-center justify-center text-xs font-semibold">
                  {conv.unread}
                </div>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
