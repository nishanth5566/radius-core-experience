import { useState } from 'react';
import { MessageCircle, Users, Send, ArrowLeft } from 'lucide-react';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';

interface ExploreScreenProps {
  userVibes: string[];
  onBack: () => void;
}

const vibeGroups = {
  yoga: {
    name: 'Yoga & Wellness',
    members: 234,
    color: 'from-pink-500 to-rose-600',
    messages: [
      { user: 'Sarah M.', message: 'Anyone up for a sunrise session tomorrow?', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100' },
      { user: 'Mike R.', message: 'I know a great spot by the park!', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100' },
    ]
  },
  fitness: {
    name: 'Fitness & Training',
    members: 487,
    color: 'from-orange-500 to-red-600',
    messages: [
      { user: 'Alex K.', message: 'Gym buddy needed for leg day 💪', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100' },
      { user: 'Jordan P.', message: 'Count me in! What time?', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100' },
    ]
  },
  cafes: {
    name: 'Café Lovers',
    members: 312,
    color: 'from-amber-500 to-yellow-600',
    messages: [
      { user: 'Emma L.', message: 'Found an amazing new spot downtown!', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100' },
      { user: 'Chris B.', message: 'Share the location please! ☕', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100' },
    ]
  },
  gaming: {
    name: 'Gaming Squad',
    members: 521,
    color: 'from-purple-500 to-indigo-600',
    messages: [
      { user: 'Tyler G.', message: 'Anyone online for a quick match?', avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100' },
      { user: 'Sam W.', message: 'Give me 10 mins!', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100' },
    ]
  },
  music: {
    name: 'Music Enthusiasts',
    members: 398,
    color: 'from-blue-500 to-cyan-600',
    messages: [
      { user: 'Maya S.', message: 'Concert this weekend, who\'s coming?', avatar: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=100' },
      { user: 'David L.', message: 'I\'m in! What genre?', avatar: 'https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=100' },
    ]
  },
  study: {
    name: 'Study Group',
    members: 276,
    color: 'from-green-500 to-emerald-600',
    messages: [
      { user: 'Lisa C.', message: 'Library meetup at 3pm?', avatar: 'https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?w=100' },
      { user: 'Tom H.', message: 'Perfect! See you there', avatar: 'https://images.unsplash.com/photo-1504593811423-6dd665756598?w=100' },
    ]
  },
};

export function ExploreScreen({ userVibes, onBack }: ExploreScreenProps) {
  const [selectedGroup, setSelectedGroup] = useState<string | null>(null);
  const [message, setMessage] = useState('');

  const userGroups = userVibes.map(vibe => ({
    id: vibe,
    ...vibeGroups[vibe as keyof typeof vibeGroups]
  }));

  if (selectedGroup) {
    const group = vibeGroups[selectedGroup as keyof typeof vibeGroups];
    
    return (
      <div className="h-full flex flex-col bg-white">
        {/* Chat Header */}
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-4 shadow-lg">
          <div className="flex items-center gap-3">
            <button onClick={() => setSelectedGroup(null)} className="hover:bg-white/20 rounded-full p-2 transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex-1">
              <h2 className="font-semibold">{group.name}</h2>
              <p className="text-sm text-white/90">{group.members} members</p>
            </div>
            <Users className="w-6 h-6" />
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4 bg-gray-50">
          {group.messages.map((msg, idx) => (
            <div key={idx} className="flex gap-3">
              <Avatar className="w-10 h-10 border-2 border-white shadow">
                <AvatarImage src={msg.avatar} alt={msg.user} />
                <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white text-sm">
                  {msg.user.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-baseline gap-2 mb-1">
                  <span className="font-medium text-sm text-gray-900">{msg.user}</span>
                  <span className="text-xs text-gray-500">just now</span>
                </div>
                <div className="bg-white rounded-2xl rounded-tl-sm px-4 py-2 shadow-sm">
                  <p className="text-gray-800">{msg.message}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Message Input */}
        <div className="border-t border-gray-200 bg-white px-6 py-4">
          <div className="flex gap-2">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type a message..."
              className="flex-1 h-11 rounded-full border-gray-300 focus:border-purple-500 focus:ring-purple-500"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && message.trim()) {
                  setMessage('');
                }
              }}
            />
            <Button
              onClick={() => message.trim() && setMessage('')}
              className="h-11 w-11 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 p-0 shadow-lg shadow-purple-500/30"
            >
              <Send className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-purple-50/50 to-blue-50/50">
      {/* Header */}
      <div className="px-6 pt-12 pb-6">
        <div className="flex items-center gap-3 mb-2">
          <button onClick={onBack} className="hover:bg-white/60 rounded-full p-2 transition-colors">
            <ArrowLeft className="w-5 h-5 text-gray-700" />
          </button>
          <h1 className="text-3xl font-semibold text-gray-900">Explore Groups</h1>
        </div>
        <p className="text-lg text-gray-600 ml-12">Connect with your communities</p>
      </div>

      {/* Groups */}
      <div className="flex-1 overflow-y-auto px-6 pb-6 space-y-3">
        {userGroups.length > 0 ? (
          userGroups.map((group) => (
            <Card
              key={group.id}
              onClick={() => setSelectedGroup(group.id)}
              className="bg-white border-0 shadow-md hover:shadow-lg transition-all cursor-pointer rounded-2xl overflow-hidden"
            >
              <div className="flex items-center gap-4 p-4">
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${group.color} flex items-center justify-center shadow-lg`}>
                  <MessageCircle className="w-7 h-7 text-white" strokeWidth={2} />
                </div>
                
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">{group.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <Users className="w-4 h-4 text-gray-500" />
                    <span className="text-sm text-gray-600">{group.members} members</span>
                  </div>
                </div>

                <div className="flex flex-col items-end">
                  <div className="w-2 h-2 rounded-full bg-green-500 mb-1"></div>
                  <span className="text-xs text-gray-500">Active</span>
                </div>
              </div>

              {/* Preview last message */}
              <div className="px-4 pb-4">
                <div className="flex items-center gap-2 text-sm text-gray-600 bg-gray-50 rounded-xl px-3 py-2">
                  <span className="font-medium">{group.messages[group.messages.length - 1].user}:</span>
                  <span className="truncate">{group.messages[group.messages.length - 1].message}</span>
                </div>
              </div>
            </Card>
          ))
        ) : (
          <div className="text-center py-12">
            <MessageCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-600">No groups yet. Select your vibes to join communities!</p>
          </div>
        )}
      </div>
    </div>
  );
}
