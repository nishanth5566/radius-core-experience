import { useState } from 'react';
import { MapPin, User, Home, Compass, MessageCircle } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Card } from './ui/card';
import { toast } from 'sonner@2.0.3';

interface MapScreenProps {
  userEmail: string;
  userVibes: string[];
  onNavigate: (screen: string) => void;
}

const nearbyUsers = [
  {
    id: 1,
    name: 'Alex Chen',
    distance: '0.3 km',
    vibe: 'Cafés',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop',
    lat: 52,
    lng: 30,
  },
  {
    id: 2,
    name: 'Maya Patel',
    distance: '0.5 km',
    vibe: 'Yoga',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop',
    lat: 48,
    lng: 65,
  },
  {
    id: 3,
    name: 'Jordan Smith',
    distance: '0.8 km',
    vibe: 'Gaming',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
    lat: 70,
    lng: 45,
  },
  {
    id: 4,
    name: 'Sam Williams',
    distance: '1.1 km',
    vibe: 'Music',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop',
    lat: 35,
    lng: 55,
  },
];

export function MapScreen({ userEmail, userVibes, onNavigate }: MapScreenProps) {
  const [currentUserIndex, setCurrentUserIndex] = useState(0);
  const currentUser = nearbyUsers[currentUserIndex];

  const handleNextUser = () => {
    setCurrentUserIndex((prev) => (prev + 1) % nearbyUsers.length);
  };

  return (
    <div className="h-full relative bg-gray-100">
      {/* Map Background with Pins */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-100 via-purple-50 to-blue-50">
        {/* Simplified map grid */}
        <div className="absolute inset-0 opacity-20">
          <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="gray" strokeWidth="0.5"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>

        {/* User Pins */}
        {nearbyUsers.map((user) => (
          <div
            key={user.id}
            className="absolute animate-pulse"
            style={{
              left: `${user.lng}%`,
              top: `${user.lat}%`,
              transform: 'translate(-50%, -100%)',
            }}
          >
            <div className="relative">
              <MapPin
                className={`w-8 h-8 ${
                  user.id === currentUser.id
                    ? 'text-purple-600 fill-purple-600'
                    : 'text-blue-500 fill-blue-500'
                }`}
                strokeWidth={2}
              />
              {user.id === currentUser.id && (
                <div className="absolute -inset-2 rounded-full border-2 border-purple-600 animate-ping opacity-75" />
              )}
            </div>
          </div>
        ))}

        {/* Your Location (center) */}
        <div
          className="absolute"
          style={{
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
          }}
        >
          <div className="relative">
            <div className="w-4 h-4 rounded-full bg-gradient-to-br from-blue-600 to-purple-700 border-2 border-white shadow-lg" />
            <div className="absolute -inset-3 rounded-full border-2 border-blue-600 opacity-30 animate-ping" />
          </div>
        </div>
      </div>

      {/* Top Card */}
      <div className="absolute top-0 left-0 right-0 pt-6 px-6 z-10">
        <Card className="bg-white/95 backdrop-blur-sm border-0 shadow-lg rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-semibold text-gray-900">People near you</h2>
              <p className="text-sm text-gray-600">{nearbyUsers.length} online now</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
              <span className="text-white font-semibold">{nearbyUsers.length}</span>
            </div>
          </div>
        </Card>
      </div>

      {/* Bottom Profile Card */}
      <div className="absolute bottom-20 left-0 right-0 px-6 z-10">
        <Card 
          className="bg-white border-0 shadow-2xl rounded-3xl p-6 hover:shadow-purple-500/20 transition-all"
        >
          <div className="flex items-center gap-4">
            <Avatar className="w-16 h-16 border-2 border-purple-500">
              <AvatarImage src={currentUser.avatar} alt={currentUser.name} />
              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                {currentUser.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1">
              <h3 className="font-semibold text-gray-900">{currentUser.name}</h3>
              <p className="text-sm text-gray-600">{currentUser.distance} away</p>
              <div className="mt-1 inline-flex items-center gap-1 px-2 py-1 rounded-full bg-purple-100 text-purple-700 text-xs font-medium">
                {currentUser.vibe}
              </div>
            </div>

            <div className="flex gap-2">
              <button 
                onClick={() => toast.success(`Started a chat with ${currentUser.name}!`, {
                  description: 'Say hello and make a connection',
                  duration: 3000,
                })}
                className="p-3 rounded-xl bg-white border-2 border-purple-200 text-purple-600 hover:bg-purple-50 transition-all"
              >
                <MessageCircle className="w-5 h-5" strokeWidth={2} />
              </button>
              
              <button 
                onClick={handleNextUser}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-blue-500 to-purple-600 text-white text-sm font-medium shadow-lg shadow-purple-500/30 hover:shadow-purple-500/50 transition-all"
              >
                Next
              </button>
            </div>
          </div>
        </Card>
      </div>

      {/* Bottom Navigation */}
      <div className="absolute bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-10">
        <div className="flex items-center justify-around py-3">
          <button className="flex flex-col items-center gap-1 px-6 py-2 text-purple-600">
            <MapPin className="w-6 h-6" strokeWidth={2} />
            <span className="text-xs font-medium">Map</span>
          </button>
          
          <button 
            onClick={() => onNavigate('explore')}
            className="flex flex-col items-center gap-1 px-6 py-2 text-gray-400 hover:text-gray-600 transition-colors font-bold"
          >
            <Compass className="w-6 h-6" strokeWidth={2} />
            <span className="text-xs font-medium">Explore</span>
          </button>
          
          <button 
            onClick={() => onNavigate('chats')}
            className="flex flex-col items-center gap-1 px-6 py-2 text-gray-400 hover:text-gray-600 transition-colors"
          >
            <MessageCircle className="w-6 h-6" strokeWidth={2} />
            <span className="text-xs font-medium">Chats</span>
          </button>
          
          <button 
            onClick={() => onNavigate('profile')}
            className="flex flex-col items-center gap-1 px-6 py-2 text-gray-400 hover:text-gray-600 transition-colors"
          >
            <User className="w-6 h-6" strokeWidth={2} />
            <span className="text-xs font-medium">Profile</span>
          </button>
        </div>
      </div>
    </div>
  );
}