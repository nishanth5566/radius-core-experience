import { useState } from 'react';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Button } from './ui/button';
import { Radius, Dumbbell, Coffee, Gamepad2, Music, BookOpen, Heart } from 'lucide-react';

interface SignupScreenProps {
  onGetStarted: (data: { name: string; gender: string; email: string; bio: string; vibes: string[] }) => void;
  onLoginClick: () => void;
}

const vibes = [
  { id: 'yoga', label: 'Yoga', icon: Heart },
  { id: 'fitness', label: 'Fitness', icon: Dumbbell },
  { id: 'cafes', label: 'Cafés', icon: Coffee },
  { id: 'gaming', label: 'Gaming', icon: Gamepad2 },
  { id: 'music', label: 'Music', icon: Music },
  { id: 'study', label: 'Study', icon: BookOpen },
];

export function SignupScreen({ onGetStarted, onLoginClick }: SignupScreenProps) {
  const [name, setName] = useState('');
  const [gender, setGender] = useState('');
  const [email, setEmail] = useState('');
  const [bio, setBio] = useState('');
  const [selectedVibes, setSelectedVibes] = useState<string[]>([]);

  const toggleVibe = (vibeId: string) => {
    if (selectedVibes.includes(vibeId)) {
      setSelectedVibes(selectedVibes.filter((v) => v !== vibeId));
    } else {
      setSelectedVibes([...selectedVibes, vibeId]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && gender && email && bio && selectedVibes.length > 0) {
      onGetStarted({ name, gender, email, bio, vibes: selectedVibes });
    }
  };

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-white to-blue-50/30 overflow-y-auto">
      <div className="flex-1 px-8 py-12">
        {/* Logo */}
        <div className="flex flex-col items-center space-y-4 mb-8">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-lg">
            <Radius className="w-10 h-10 text-white" strokeWidth={2} />
          </div>
          <div className="text-center">
            <h1 className="text-3xl font-semibold text-gray-900 mb-2">Create your account</h1>
            <p className="text-lg text-gray-600">Tell us about yourself</p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Name */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Name</label>
            <Input
              type="text"
              placeholder="Your full name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="h-12 rounded-xl border-gray-200 focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>

          {/* Gender */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Gender</label>
            <div className="grid grid-cols-3 gap-3">
              {['Male', 'Female', 'Other'].map((genderOption) => (
                <button
                  key={genderOption}
                  type="button"
                  onClick={() => setGender(genderOption)}
                  className={`
                    h-12 rounded-xl border-2 transition-all duration-200 font-medium
                    ${
                      gender === genderOption
                        ? 'border-purple-500 bg-gradient-to-br from-blue-500 to-purple-600 text-white shadow-md'
                        : 'border-gray-200 bg-white hover:border-purple-300 text-gray-700'
                    }
                  `}
                >
                  {genderOption}
                </button>
              ))}
            </div>
          </div>

          {/* Email */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Email</label>
            <Input
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-12 rounded-xl border-gray-200 focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>

          {/* Bio */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">About you</label>
            <Textarea
              placeholder="Tell us a little about yourself..."
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="min-h-24 rounded-xl border-gray-200 focus:border-blue-500 focus:ring-blue-500 resize-none"
              required
              maxLength={200}
            />
            <p className="text-xs text-gray-500 text-right">{bio.length}/200</p>
          </div>

          {/* Vibes */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-gray-700">Your vibes</label>
            <div className="grid grid-cols-2 gap-3">
              {vibes.map((vibe) => {
                const Icon = vibe.icon;
                const isSelected = selectedVibes.includes(vibe.id);
                
                return (
                  <button
                    key={vibe.id}
                    type="button"
                    onClick={() => toggleVibe(vibe.id)}
                    className={`
                      h-24 rounded-xl border-2 transition-all duration-200
                      flex flex-col items-center justify-center gap-2
                      ${
                        isSelected
                          ? 'border-purple-500 bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg shadow-purple-500/30 text-white'
                          : 'border-gray-200 bg-white hover:border-purple-300 text-gray-700'
                      }
                    `}
                  >
                    <Icon className="w-6 h-6" strokeWidth={2} />
                    <span className="text-sm font-medium">{vibe.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <Button
            type="submit"
            disabled={!name || !gender || !email || !bio || selectedVibes.length === 0}
            className="w-full h-12 rounded-xl bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium shadow-lg shadow-blue-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Get Started
          </Button>
        </form>

        {/* Login link */}
        <div className="text-center mt-6">
          <button
            onClick={onLoginClick}
            className="text-sm text-gray-600 hover:text-blue-600 transition-colors"
          >
            Already have an account? <span className="font-medium">Login</span>
          </button>
        </div>
      </div>
    </div>
  );
}