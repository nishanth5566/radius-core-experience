import { ArrowLeft, MapPin, Mail, User as UserIcon, Edit2, Heart, Dumbbell, Coffee, Gamepad2, Music, BookOpen } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Card } from './ui/card';
import { Button } from './ui/button';

interface ProfileScreenProps {
  userName: string;
  userGender: string;
  userEmail: string;
  userBio: string;
  userVibes: string[];
  onBack: () => void;
  onLogout: () => void;
}

const vibeIcons: { [key: string]: any } = {
  yoga: Heart,
  fitness: Dumbbell,
  cafes: Coffee,
  gaming: Gamepad2,
  music: Music,
  study: BookOpen,
};

const vibeLabels: { [key: string]: string } = {
  yoga: 'Yoga',
  fitness: 'Fitness',
  cafes: 'Cafés',
  gaming: 'Gaming',
  music: 'Music',
  study: 'Study',
};

const vibeColors: { [key: string]: string } = {
  yoga: 'from-pink-500 to-rose-600',
  fitness: 'from-orange-500 to-red-600',
  cafes: 'from-amber-500 to-yellow-600',
  gaming: 'from-purple-500 to-indigo-600',
  music: 'from-blue-500 to-cyan-600',
  study: 'from-green-500 to-emerald-600',
};

export function ProfileScreen({ userName, userGender, userEmail, userBio, userVibes, onBack, onLogout }: ProfileScreenProps) {
  // Generate initials from name
  const initials = userName.split(' ').map(n => n[0]).join('').toUpperCase();

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-purple-50/50 to-blue-50/50">
      {/* Header with gradient */}
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 pt-12 pb-24 px-6 relative">
        <button 
          onClick={onBack} 
          className="absolute top-12 left-6 hover:bg-white/20 rounded-full p-2 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <h1 className="text-2xl font-semibold text-white text-center">Profile</h1>
      </div>

      {/* Profile Content */}
      <div className="flex-1 overflow-y-auto px-6 -mt-16 pb-6">
        {/* Profile Card */}
        <Card className="bg-white border-0 shadow-xl rounded-3xl p-6 mb-6">
          <div className="flex flex-col items-center -mt-16 mb-4">
            <Avatar className="w-28 h-28 border-4 border-white shadow-xl">
              <AvatarImage src={`https://ui-avatars.com/api/?name=${encodeURIComponent(userName)}&size=200&background=gradient&color=fff`} alt={userName} />
              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white text-2xl">
                {initials}
              </AvatarFallback>
            </Avatar>
            <button className="mt-3 p-2 bg-purple-100 rounded-full hover:bg-purple-200 transition-colors">
              <Edit2 className="w-4 h-4 text-purple-600" />
            </button>
          </div>

          <div className="text-center mb-6">
            <h2 className="text-2xl font-semibold text-gray-900 mb-1">{userName}</h2>
            <p className="text-gray-600">{userGender}</p>
          </div>

          {/* Info sections */}
          <div className="space-y-4">
            {/* Email */}
            <div className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl">
              <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
                <Mail className="w-5 h-5 text-blue-600" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-gray-500 font-medium">Email</p>
                <p className="text-gray-900">{userEmail}</p>
              </div>
            </div>

            {/* Bio */}
            <div className="p-4 bg-gray-50 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <UserIcon className="w-4 h-4 text-gray-600" />
                <p className="text-xs text-gray-500 font-medium">About</p>
              </div>
              <p className="text-gray-900">{userBio}</p>
            </div>

            {/* Vibes */}
            <div className="p-4 bg-gray-50 rounded-xl">
              <div className="flex items-center gap-2 mb-3">
                <MapPin className="w-4 h-4 text-gray-600" />
                <p className="text-xs text-gray-500 font-medium">My Vibes</p>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {userVibes.map((vibe) => {
                  const Icon = vibeIcons[vibe];
                  const color = vibeColors[vibe];
                  const label = vibeLabels[vibe];
                  
                  return (
                    <div
                      key={vibe}
                      className={`h-20 rounded-xl bg-gradient-to-br ${color} flex flex-col items-center justify-center gap-1 text-white shadow-md`}
                    >
                      <Icon className="w-5 h-5" strokeWidth={2} />
                      <span className="text-xs font-medium">{label}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </Card>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button
            onClick={() => {}}
            className="w-full h-12 rounded-xl bg-white border-2 border-gray-200 text-gray-700 hover:bg-gray-50 font-medium"
          >
            Edit Profile
          </Button>
          
          <Button
            onClick={onLogout}
            className="w-full h-12 rounded-xl bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 text-white font-medium shadow-lg shadow-red-500/30"
          >
            Logout
          </Button>
        </div>
      </div>
    </div>
  );
}
