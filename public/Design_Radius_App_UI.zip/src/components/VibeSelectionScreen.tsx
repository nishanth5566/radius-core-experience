import { Button } from './ui/button';
import { Dumbbell, Coffee, Gamepad2, Music, BookOpen, Heart } from 'lucide-react';

interface VibeSelectionScreenProps {
  selectedVibes: string[];
  onVibesChange: (vibes: string[]) => void;
  onContinue: () => void;
}

const vibes = [
  { id: 'yoga', label: 'Yoga', icon: Heart },
  { id: 'fitness', label: 'Fitness', icon: Dumbbell },
  { id: 'cafes', label: 'Cafés', icon: Coffee },
  { id: 'gaming', label: 'Gaming', icon: Gamepad2 },
  { id: 'music', label: 'Music', icon: Music },
  { id: 'study', label: 'Study', icon: BookOpen },
];

export function VibeSelectionScreen({
  selectedVibes,
  onVibesChange,
  onContinue,
}: VibeSelectionScreenProps) {
  const toggleVibe = (vibeId: string) => {
    if (selectedVibes.includes(vibeId)) {
      onVibesChange(selectedVibes.filter((v) => v !== vibeId));
    } else {
      onVibesChange([...selectedVibes, vibeId]);
    }
  };

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-purple-50/50 to-blue-50/50">
      {/* Header */}
      <div className="px-8 pt-16 pb-8">
        <h1 className="text-3xl font-semibold text-gray-900 mb-2">
          What's your vibe?
        </h1>
        <p className="text-lg text-gray-600">Pick what you're into</p>
      </div>

      {/* Vibes Grid */}
      <div className="flex-1 px-8 pb-8">
        <div className="grid grid-cols-2 gap-4">
          {vibes.map((vibe) => {
            const Icon = vibe.icon;
            const isSelected = selectedVibes.includes(vibe.id);
            
            return (
              <button
                key={vibe.id}
                onClick={() => toggleVibe(vibe.id)}
                className={`
                  h-32 rounded-2xl border-2 transition-all duration-200
                  flex flex-col items-center justify-center gap-3
                  ${
                    isSelected
                      ? 'border-purple-500 bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg shadow-purple-500/30 text-white'
                      : 'border-gray-200 bg-white hover:border-purple-300 text-gray-700'
                  }
                `}
              >
                <Icon className="w-8 h-8" strokeWidth={2} />
                <span className="font-medium">{vibe.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Continue Button */}
      <div className="px-8 pb-8">
        <Button
          onClick={onContinue}
          disabled={selectedVibes.length === 0}
          className="w-full h-12 rounded-xl bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-medium shadow-lg shadow-purple-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Continue
        </Button>
      </div>
    </div>
  );
}
