import { useState } from 'react';
import { LoginScreen } from './components/LoginScreen';
import { SignupScreen } from './components/SignupScreen';
import { VibeSelectionScreen } from './components/VibeSelectionScreen';
import { MapScreen } from './components/MapScreen';
import { ExploreScreen } from './components/ExploreScreen';
import { ChatsScreen } from './components/ChatsScreen';
import { ProfileScreen } from './components/ProfileScreen';
import { Toaster } from './components/ui/sonner';

type Screen = 'login' | 'signup' | 'vibes' | 'map' | 'explore' | 'chats' | 'profile';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('login');
  const [userName, setUserName] = useState('');
  const [userGender, setUserGender] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [selectedVibes, setSelectedVibes] = useState<string[]>([]);
  const [userBio, setUserBio] = useState('');

  return (
    <div className="min-h-screen bg-white flex items-center justify-center">
      <div className="w-full max-w-md h-screen bg-white shadow-2xl overflow-hidden relative">
        {currentScreen === 'login' && (
          <LoginScreen
            onContinue={(email) => {
              setUserEmail(email);
              setCurrentScreen('vibes');
            }}
            onSignupClick={() => setCurrentScreen('signup')}
          />
        )}
        
        {currentScreen === 'signup' && (
          <SignupScreen
            onGetStarted={(data) => {
              setUserName(data.name);
              setUserGender(data.gender);
              setUserEmail(data.email);
              setUserBio(data.bio);
              setSelectedVibes(data.vibes);
              setCurrentScreen('map');
            }}
            onLoginClick={() => setCurrentScreen('login')}
          />
        )}
        
        {currentScreen === 'vibes' && (
          <VibeSelectionScreen
            selectedVibes={selectedVibes}
            onVibesChange={setSelectedVibes}
            onContinue={() => setCurrentScreen('map')}
          />
        )}
        
        {currentScreen === 'map' && (
          <MapScreen
            userEmail={userEmail}
            userVibes={selectedVibes}
            onNavigate={(screen) => setCurrentScreen(screen as Screen)}
          />
        )}
        
        {currentScreen === 'explore' && (
          <ExploreScreen
            userVibes={selectedVibes}
            onBack={() => setCurrentScreen('map')}
          />
        )}
        
        {currentScreen === 'chats' && (
          <ChatsScreen
            onBack={() => setCurrentScreen('map')}
          />
        )}
        
        {currentScreen === 'profile' && (
          <ProfileScreen
            userName={userName}
            userGender={userGender}
            userEmail={userEmail}
            userBio={userBio}
            userVibes={selectedVibes}
            onBack={() => setCurrentScreen('map')}
            onLogout={() => {
              setCurrentScreen('login');
              setUserName('');
              setUserGender('');
              setUserEmail('');
              setUserBio('');
              setSelectedVibes([]);
            }}
          />
        )}
      </div>
      <Toaster />
    </div>
  );
}