
  # Design Radius App UI

  This is a code bundle for Design Radius App UI. The original project is available at https://www.figma.com/design/FyMMlDtPUweWEGKcpI3T0e/Design-Radius-App-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  